<!DOCTYPE html>
<html lang="pl">
<head>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <meta charset="UTF-8">
    <title>Witamy</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <center><div id="duze3"><br><img src="quiz.png" alt="Quiz" width="300" height="255"></div></center>
<form method="POST" action="quiz.php">
    <div id="duze1"><br>
<h2>Witamy!!!</h2>
<button id="przycisk1"><b>Rozwiąż Quiz</b></button>
</div>
</form>
</body>
</html>